//
//  VKMethods.swift
//  vkapp
//
//  Created by Vasiliy Kapyshkov on 08.03.2021.
//

import Foundation

enum VKMethods: String {
    case friendsGet = "friends.get"
    case groupsGet = "groups.get"
    case photosGet = "photos.getAll"
}
