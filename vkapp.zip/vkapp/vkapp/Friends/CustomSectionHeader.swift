//
//  CustomSectionHeader.swift
//  vkapp
//
//  Created by Vasiliy Kapyshkov on 04.02.2021.
//

import UIKit

class CustomSectionHeader: UITableViewHeaderFooterView {

    @IBOutlet var labelView: UILabel?

}
