//
//  UserCell.swift
//  vkapp
//
//  Created by Vasiliy Kapyshkov on 24.01.2021.
//

import UIKit

class UserCell: UICollectionViewCell {
    
    @IBOutlet var photo: UIImageView?
    @IBOutlet var likeControl: LikeControl?
}
