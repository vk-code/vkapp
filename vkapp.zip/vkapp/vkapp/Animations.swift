//
//  Animations.swift
//  vkapp
//
//  Created by Vasiliy Kapyshkov on 07.02.2021.
//

import UIKit

class MyAnimations {
    
    @objc func animateAvatar(_ sender: AvatarView) {
//        guard let avatarView = self.avatar else { return }
//        
//        UIView.animate(withDuration: 0.2) {
//            avatarView.transform = CGAffineTransform(scaleX: 0.5, y: 1)
//        } completion: { _ in
//            UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0.6, options: [], animations: {
//                avatarView.transform = CGAffineTransform(scaleX: 1, y: 1)
//            })
//        }
    }
}
